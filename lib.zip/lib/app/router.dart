
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/auth/presentation/pages/account_status_page.dart';
import '../features/auth/presentation/pages/forgot_password_page.dart';
import '../features/auth/presentation/pages/login_page.dart';
import '../features/auth/presentation/pages/register_page.dart';
import '../features/auth/presentation/pages/reset_password_page.dart';
import '../features/auth/presentation/pages/splash_page.dart';
import '../features/auth/presentation/pages/verify_email_page.dart';
import '../features/auth/presentation/pages/welcome_page.dart';
import '../features/agents/presentation/pages/agent_dashboard_page.dart'; // Module 10
import '../features/agents/presentation/pages/agent_inquiries_page.dart';
import '../features/agents/presentation/pages/agent_listing_detail_page.dart';
import '../features/agents/presentation/pages/agent_listings_page.dart';
import '../features/agents/presentation/pages/agent_profile_page.dart';
import '../features/agents/presentation/pages/agent_statistics_page.dart';
import '../features/agents/presentation/pages/agent_verification_page.dart';
import '../features/agents/presentation/pages/edit_agent_profile_page.dart';
import '../features/agents/presentation/pages/public_agent_profile_page.dart';
import '../features/auth/providers/auth_provider.dart';
import '../features/messaging/presentation/pages/chat_page.dart';
import '../features/map/presentation/pages/map_page.dart'; // Module 06
import '../features/profile/presentation/profile_page.dart'; // Module 02
import '../features/properties/presentation/pages/property_details_page.dart'; // Module 05
import '../features/property_discovery/presentation/screens/home_discovery_screen.dart';
import '../features/search/presentation/pages/search_page.dart'; // Module 04
import '../features/favorites/presentation/pages/favorites_page.dart'; // Module 07
import '../features/publishing/presentation/pages/publish_page.dart'; // Module 08

import '../features/listings/presentation/pages/my_listings_page.dart'; // Module 09
import 'app_shell.dart';
import 'placeholder_pages.dart';
import 'router_guard.dart';
import 'routes.dart';

final routerProvider = Provider<GoRouter>((ref) {
  // Re-run the redirect whenever the auth state changes.
  final refresh = ValueNotifier<int>(0);
  ref.listen(authControllerProvider, (_, __) => refresh.value++);
  ref.onDispose(refresh.dispose);

  final router = GoRouter(
    initialLocation: Routes.splash,
    refreshListenable: refresh,
    redirect: (context, state) =>
        authRedirect(ref.read(authControllerProvider), state.matchedLocation),
    routes: [
      // ---- Module 01 -------------------------------------------------------
      GoRoute(path: Routes.splash, builder: (_, __) => const SplashPage()),
      GoRoute(path: Routes.welcome, builder: (_, __) => const WelcomePage()),
      GoRoute(path: Routes.login, builder: (_, __) => const LoginPage()),
      GoRoute(path: Routes.register, builder: (_, __) => const RegisterPage()),
      GoRoute(path: Routes.forgotPassword, builder: (_, __) => const ForgotPasswordPage()),
      GoRoute(
        path: Routes.resetPassword,
        builder: (_, state) => ResetPasswordPage(code: state.uri.queryParameters['oobCode']),
      ),
      GoRoute(path: Routes.verifyEmail, builder: (_, __) => const VerifyEmailPage()),
      GoRoute(path: Routes.accountStatus, builder: (_, __) => const AccountStatusPage()),
      GoRoute(path: Routes.adminDashboard, builder: (_, __) => const AdminPlaceholderPage()),

      // ---- Main app: bottom navigation ------------------------------------
      StatefulShellRoute.indexedStack(
        builder: (_, __, shell) => AppShell(shell: shell),
        branches: [
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.home, builder: (_, __) => const HomeDiscoveryScreen()), // Module 03
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: Routes.search,
              builder: (_, state) => SearchPage(params: state.uri.queryParameters),
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: Routes.map,
              builder: (_, state) => MapPage(params: state.uri.queryParameters), // Module 06
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(
              path: Routes.favorites,
              builder: (_, __) => const FavoritesPage(), // Module 07
            ),
          ]),
          StatefulShellBranch(routes: [
            GoRoute(path: Routes.profile, builder: (_, __) => const UserProfilePage()), // Module 02
          ]),
        ],
      ),

      // ---- Full-screen pages pushed on top of the shell --------------------
      GoRoute(
        path: Routes.propertyDetailsPattern,
        builder: (_, state) => PropertyDetailsPage(propertyId: state.pathParameters['id'] ?? ''),
      ),
      // ---- Module 10: Agent / Agency ---------------------------------------
      GoRoute(
        path: Routes.agentDashboard,
        builder: (_, __) => const AgentDashboardPage(),
        routes: [
          GoRoute(path: 'setup', builder: (_, __) => const EditAgentProfilePage(setup: true)),
          GoRoute(
            path: 'profile',
            builder: (_, __) => const AgentProfilePage(),
            routes: [GoRoute(path: 'edit', builder: (_, __) => const EditAgentProfilePage(setup: false))],
          ),
          GoRoute(
            path: 'listings',
            builder: (_, __) => const AgentListingsPage(),
            routes: [
              GoRoute(
                path: ':propertyId',
                builder: (_, state) => AgentListingDetailPage(propertyId: state.pathParameters['propertyId'] ?? ''),
              ),
            ],
          ),
          GoRoute(path: 'inquiries', builder: (_, __) => const AgentInquiriesPage()),
          GoRoute(path: 'statistics', builder: (_, __) => const AgentStatisticsPage()),
          GoRoute(path: 'verification', builder: (_, __) => const AgentVerificationPage()),
        ],
      ),
      GoRoute(
        path: Routes.agentPublicPattern,
        builder: (_, state) => PublicAgentProfilePage(agentId: state.pathParameters['agentId'] ?? ''),
      ),
      GoRoute(
        path: Routes.chatPattern,
        builder: (_, state) => ChatPage(conversationId: state.pathParameters['conversationId'] ?? ''),
      ),
      GoRoute(
        path: Routes.publish,
        builder: (_, __) => const PublishPage(), // Module 08
      ),
      GoRoute(
        path: Routes.myListings,
        builder: (_, _) => const MyListingsPage(),
      ),
    ],
  );
  ref.onDispose(router.dispose);
  return router;
});